public class Main {
    public static void main(String[] args) {
        int price = 15000;
        int mile = 20;
        int bonusInMoney = price / mile;
        System.out.println(bonusInMoney);
    }
}