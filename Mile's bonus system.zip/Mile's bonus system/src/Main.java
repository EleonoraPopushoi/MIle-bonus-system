public class Main {
    public static void main(String[] args) {
        int price = 15000;
        int mile = 20;
        int bonus = price/mile;
        System.out.println(bonus);
    }
}